package models;

public class GameBoard {

  private Player p1;

  private Player p2;

  private boolean gameStarted;

  private int turn;

  private char[][] boardState;

  private int winner;

  private boolean isDraw;
 
  
  /** Create GameBoard.
   * 
   * @param gbp1 playerP1
   * @param gbp2 playerP2
   * @param gbStarted gameStarted
   * @param gbturn turn
   * @param gbState boardState
   * @param gbwinner winner
   * @param gbisDraw isDraw
   */
  public GameBoard(Player gbp1, Player gbp2, boolean gbStarted,
      int gbturn, char[][] gbState, int gbwinner, boolean gbisDraw) {
    p1 = gbp1;
    p2 = gbp2;
    gameStarted = gbStarted;
    turn = gbturn;
    boardState = gbState;
    winner = gbwinner;
    isDraw = gbisDraw;
  }
  
  /*
   * get object Player1
   */
  public Player getP1() {
    return p1;
  }
  
  /*
   * set object Player1
   */
  public void setP1(Player p1) {
    this.p1 = p1;
  }
  
  /*
   * get object Player2
   */
  public Player getP2() {
    return p2;
  }
  
  /*
   * set object Player2
   */
  public void setP2(Player p2) {
    this.p2 = p2;
  }
  
  /*
   * get whether the game is started
   */
  public boolean isGameStarted() {
    return gameStarted;
  }
  
  /*
   * set game status, whether it is started
   */
  public void setGameStarted(boolean gameStarted) {
    this.gameStarted = gameStarted;
  }
  
  /*
   * get current turn
   */
  public int getTurn() {
    return turn;
  }

  /*
   * set current turn
   */
  public void setTurn(int turn) {
    this.turn = turn;
  }
  
  /*
   * get current board state
   */
  public char[][] getBoardState() {
    return boardState;
  }
  
  /*
   * set current board state
   */
  public void setBoardState(char[][] boardState) {
    this.boardState = boardState;
  }
  
  /*
   * get which player is the winner
   */
  public int getWinner() {
    return winner;
  }
  
  /*
   * set which player is the winner
   */
  public void setWinner(int winner) {
    this.winner = winner;
  }
  
  /*
   * get whether the game is draw
   */
  public boolean isDraw() {
    return isDraw;
  }
  
  /*
   * set draw for the game
   */
  public void setDraw(boolean isDraw) {
    this.isDraw = isDraw;
  }
}
