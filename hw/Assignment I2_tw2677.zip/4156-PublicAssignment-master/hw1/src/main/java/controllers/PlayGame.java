package controllers;

import com.google.gson.Gson;
import io.javalin.Javalin;
import java.io.IOException;
import java.util.Queue;
import models.GameBoard;
import models.Message;
import models.Move;
import models.Player;
import org.eclipse.jetty.websocket.api.Session;

public class PlayGame {

  private static final int PORT_NUMBER = 8080;

  private static Javalin app;

  /** Main method of the application.
   * @param args Command line arguments
   */

  public static void main(final String[] args) {
    boolean gameStarted = false;
    int turn = 0;
    char[][] boardState = new char[3][3];
    int winner = 0;
    boolean isDraw = false;
    final GameBoard board = new GameBoard(null, null, gameStarted, turn, 
        boardState, winner, isDraw);
    Gson gson = new Gson();
    sendGameBoardToAllPlayers(gson.toJson(board));

    app = Javalin.create(config -> {
      config.addStaticFiles("/public");
    }).start(PORT_NUMBER);

    // Test Echo Server
    app.post("/echo", ctx -> {
      ctx.result(ctx.body());
    });
    
    
    // New Game
    app.get("/newgame", ctx -> {
      ctx.redirect("/tictactoe.html");
    });
    
    // Start Game
    app.post("/startgame", ctx -> {
      char type = ctx.body().charAt(5);
      Player p1 = new Player(type, 1);
      board.setP1(p1);
      board.setP2(null);
      board.setGameStarted(false);
      board.setTurn(1);
      board.setBoardState(new char[3][3]);
      board.setWinner(0);
      board.setDraw(false);
      ctx.result(gson.toJson(board));
    });
    
    // Join Game
    app.get("/joingame", ctx -> {
      ctx.redirect("/tictactoe.html?p=2");
      char type = 'X';
      if (board.getP1().getType() == 'X') {
        type = 'O';
      }
      Player p2 = new Player(type, 2);
      board.setGameStarted(true);
      board.setP2(p2);
      sendGameBoardToAllPlayers(gson.toJson(board));
    });
    
    // Move
    app.post("/move/:playerId", ctx -> {
      // get current player's info
      int playerId = (int) ctx.pathParam("playerId").charAt(0) - (int) ('0');
      Player currentPlayer = board.getP1();
      if (playerId == 2) {
        currentPlayer = board.getP2();
      }
      
      // get coordinate of moving
      int coordinateX = (int) ctx.body().charAt(2) - (int) ('0');
      int coordinateY = (int) ctx.body().charAt(6) - (int) ('0');
      
      int currentTurn = board.getTurn();
      int currentWinner = board.getWinner();
      char[][] currentBoardState = board.getBoardState();
      
      Message message = new Message(false, 0, "" + board.getWinner() + board.isDraw());
      System.out.println(message.getMessage());
      
      // run the following if the game is not ended
      if (board.isGameStarted() && currentWinner == 0 && board.isDraw() == false) {
        
        if (currentBoardState[coordinateX][coordinateY] == '\u0000' 
            && playerId == 2 - (currentTurn % 2)) {
          message.setMoveValidity(true);
          message.setMessage("This move is valid.");
          message.setCode(100);
          
          Move move = new Move(currentPlayer, coordinateX, coordinateY);
          char[][] nextBoardState = move.conduct(board);
          board.setBoardState(nextBoardState);
       
          
          currentWinner  = board.checkWinner(currentTurn);
          if (currentWinner != 0) {
            board.updateWinner(currentWinner);
          }

          currentTurn = 2 - (currentTurn + 1) % 2;
          board.setTurn(currentTurn);
          sendGameBoardToAllPlayers(gson.toJson(board));
          
        } else if (playerId != 2 - (currentTurn % 2)) {
          message.setMessage("Please wait for Player" + (2 - (currentTurn % 2)));
        } else {
          message.setMessage("Invalid move. Please click again.");
        }
        
      }

      ctx.result(gson.toJson(message));
    });

    // Web sockets - DO NOT DELETE or CHANGE
    app.ws("/gameboard", new UiWebSocket());
  }
 
  /** Send message to all players.
   * @param gameBoardJson Gameboard JSON
   * @throws IOException Websocket message send IO Exception
   */
  private static void sendGameBoardToAllPlayers(final String gameBoardJson) {
    Queue<Session> sessions = UiWebSocket.getSessions();
    for (Session sessionPlayer : sessions) {
      try {
        sessionPlayer.getRemote().sendString(gameBoardJson);
      } catch (IOException e) {
        // Add logger here
      }
    }
  }

  public static void stop() {
    app.stop();
  }
}
